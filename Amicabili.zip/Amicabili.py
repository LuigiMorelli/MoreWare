# - Numeri amicabili - Versione 1

# - Definisci l'input
numero1 = int(input('Inserire il primo numero: '))
numero2 = int(input('Inserire il secondo numero: '))


#- Definisci le variabili
div, somma1, somma2 = 1, 0, 0

# - Cerca i divisori del primo numero e sommali tra loro
while div <= numero1 / 2:
    if numero1 % div == 0:
        somma1 += div
    div += 1

div = 1  # Riportiamo il divisore ad 1

# - Cerca i divisori del secondo numero e sommali tra loro
while div <= numero2 / 2:
    if numero2 % div == 0:
        somma2 += div
    div += 1

# - Confronta le somme: se sono uguali, i numeri sono amicabili.
if somma1 == numero2 and somma2 == numero1:
    print('I numeri sono amicabili!')
else:
    print('I numeri non sono amicabili!')