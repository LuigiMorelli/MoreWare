# - Numeri amicabili - Versione 2
# - Definiamo una lista di numeri amicabili compresi tra due numeri

# - Definisci l'input
numero1 = int(input('Inserire il primo numero: '))
numero2 = int(input('Inserire il secondo numero: '))

# - Parti dal primo numero
for i in range (numero1, numero2 + 1):
    
    #- Definisci le variabili
    div, somma1, somma2, num2 = 1, 0, 0, 0
    
    # - Cerca i divisori del primo numero e sommali tra loro
    while div <= i / 2:
        if i % div == 0:
            somma1 += div
        div += 1
        num2 = somma1

    div = 1  # Riportiamo il divisore ad 1

    # - Cerca i divisori del secondo numero e sommali tra loro
    while div <= somma1 / 2:
        if somma1 % div == 0:
            somma2 += div
        div += 1

    # - Confronta i numeri: se sono uguali, il numero e' perfetto.
    if somma1 == somma2 and i == num2:
        print("Il numero ", i, " e' un numero perfetto!")

    # - Confronta le somme: se sono uguali, i numeri sono amicabili.
    else:
        if somma1 == num2 and somma2 == i:
            print("I numeri ", i, " e  ", num2, " sono amicabili!")
